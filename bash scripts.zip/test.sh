#!/usr/bin/env bash

# Default values if no input is provided
w=${1:-1024}  # Width of output image
h=${2:-1024}  # Height of output image
t=${3:-100}   # Max threads
n=${4:-100}   # Max snowmen

# cmpile makedata
chmod +x makedata.sh

# Run makedata.sh with the given or default values
./makedata.sh $w $h $t $n

# Run plotdata.py to generate graphs
python3 plotdata.py

echo "Testing complete. Check outputimage.png, data.csv, and generated graphs."
